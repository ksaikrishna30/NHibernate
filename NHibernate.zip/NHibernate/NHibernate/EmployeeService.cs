﻿using NHibernate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NHibernate_Tutorial
{
    public class EmployeeService : IEmployeeService
    {
        ISession session = SessionFactory.OpenSession;

        public IList<Model.Employee> LoadEmployeeData()
        {
            using (session)
            {
                IQuery query = session.CreateQuery("FROM Employee");
                IList<Model.Employee> employeeInfo = query.List<Model.Employee>();
                return employeeInfo;
            }
        }

        public void InsertEmployee(string firstName, string lastName, string email)
        {
            Model.Employee employeeData = new Model.Employee()
            { 
                FirstName = firstName,
                LastName = lastName,
                Email = email
            };

            using (session)
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    try
                    {
                        session.Save(employeeData);
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        System.Windows.Forms.MessageBox.Show(ex.Message);
                        throw ex;
                    }
                }
            }
        }

        public void UpdateEmployee(int id, string firstName, string lastName, string email)
        {
            using (session)
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    try
                    {
                        IQuery query = session.CreateQuery("FROM Employee WHERE Id = '" + id + "'");
                        Model.Employee employeeData = query.List<Model.Employee>()[0];
                        employeeData.FirstName = firstName;
                        employeeData.LastName = lastName;
                        employeeData.Email = email;
                        session.Update(employeeData);
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public IList<Model.Employee> GetEmployeeDataById(string id)
        {
            using (session)
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    try
                    {
                        IQuery query = session.CreateQuery("FROM Employee WHERE Id = '" + id + "'");
                        return query.List<Model.Employee>();
                    }
                    catch (Exception ex)
                    {
                        System.Windows.Forms.MessageBox.Show(ex.Message);
                        throw ex;
                    }
                }
            }
        }
    }
}
