﻿using NHibernate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NHibernate_Tutorial.Forms
{
    public partial class EmployeeForm : Form
    {
        IEmployeeService _employeeService;
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            _employeeService.LoadEmployeeData();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            _employeeService.LoadEmployeeData();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            _employeeService.InsertEmployee(tFirstName.Text, tLastName.Text, tEmail.Text);
            _employeeService.LoadEmployeeData();
            tFirstName.Text = "";
            tLastName.Text = "";
            tEmail.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            _employeeService.UpdateEmployee(int.Parse(IdTxtBx.Text), tFirstName.Text, tLastName.Text, tEmail.Text);
            _employeeService.LoadEmployeeData();
            tFirstName.Text = "";
            tLastName.Text = "";
            tEmail.Text = "";
            IdTxtBx.Text = "";
        }

        private void dgViewEmployee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgViewEmployee.RowCount <= 1 || e.RowIndex < 0)
                return;
            string id = dgViewEmployee[0, e.RowIndex].Value.ToString();

            if (id == "")
                return;

            IList<Model.Employee> employeeInfo = _employeeService.GetEmployeeDataById(id);

            IdTxtBx.Text = employeeInfo[0].Id.ToString();
            tFirstName.Text = employeeInfo[0].FirstName.ToString();
            tLastName.Text = employeeInfo[0].LastName.ToString();
            tEmail.Text = employeeInfo[0].Email.ToString();
        }
    }
}
