﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NHibernate_Tutorial
{
    public interface IEmployeeService
    {
        IList<Model.Employee> LoadEmployeeData();
        void InsertEmployee(string firstName, string lastName, string email);
        void UpdateEmployee(int id, string firstName, string lastName, string email);
        IList<Model.Employee> GetEmployeeDataById(string id);
    }
}
